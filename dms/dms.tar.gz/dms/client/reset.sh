#!/bin/bash
rm -rf ./wtmpx.2016*
rm -rf ./*.dat
cp wtmpx.bak wtmpx 
exit 0
